import { View, Text } from 'react-native'; 

export default function Props ({mensagem}) {
    return(
        <View>
            <Text>Mensagem:{mensagem}</Text>
        </View>
    );
}
